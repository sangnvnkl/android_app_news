package com.example.sangnv.appnews;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;

import com.example.sangnv.appnews.RssGet.Item_RSS;

import java.util.Map;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
         RssItemFragment.OnListFragmentInteractionListener {

    private SectionsPagerAdapter mSectionsPagerAdapter;
    private ViewPager mViewPager;
    public TabLayout tabLayout;
    public int inDex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(ContrucVal.LIST_WEB_NAME[inDex]);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //set drawer layout
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        //set viewpager
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_0) {
            if (inDex != 0) {
                inDex = 0;
                mViewPager.removeAllViews();
                tabLayout.removeAllTabs();
                setTitle(ContrucVal.LIST_WEB_NAME[inDex]);
                mViewPager.getAdapter().notifyDataSetChanged();
                tabLayout.setupWithViewPager(mViewPager);
            }

        } else if (id == R.id.nav_1) {
            if (inDex != 1) {
                inDex = 1;
                mViewPager.removeAllViews();
                tabLayout.removeAllTabs();
                setTitle(ContrucVal.LIST_WEB_NAME[inDex]);

                mViewPager.getAdapter().notifyDataSetChanged();
                tabLayout.setupWithViewPager(mViewPager);
            }

        } else if (id == R.id.nav_2) {
            if (inDex != 2) {
                inDex = 2;
                mViewPager.removeAllViews();
                tabLayout.removeAllTabs();
                setTitle(ContrucVal.LIST_WEB_NAME[inDex]);

                mViewPager.getAdapter().notifyDataSetChanged();
                tabLayout.setupWithViewPager(mViewPager);
            }
        } else if (id == R.id.nav_3) {
            if (inDex != 3) {
                inDex = 3;
                mViewPager.removeAllViews();
                tabLayout.removeAllTabs();
                setTitle(ContrucVal.LIST_WEB_NAME[inDex]);

                mViewPager.getAdapter().notifyDataSetChanged();
                tabLayout.setupWithViewPager(mViewPager);
            }
        } else if (id == R.id.nav_info) {

        } else if (id == R.id.nav_setting) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onListFragmentInteraction(Item_RSS item) {
        //even click vao item, lấy ra link và chuyển ra webview
        //Toast.makeText(getApplicationContext(), item.getLink(), Toast.LENGTH_SHORT).show();
        Intent myIntent = new Intent(MainActivity.this, WebViewActivity.class);
        myIntent.putExtra("url", item.getLink()); //send messeage to WebViewActivity
        myIntent.putExtra("title", item.getTitle());
        startActivity(myIntent);
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentStatePagerAdapter {
        private Context mContext;
        private FragmentManager mFragmentManager;
        private Map<Integer, String> mFragmentTags;

        public SectionsPagerAdapter(Context context, FragmentManager fm) {
            super(fm);
            mFragmentManager = fm;
            mContext = context;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            return super.instantiateItem(container, position);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            return  RssItemFragment.newInstance(ContrucVal.LIST_LINK[inDex][position]);
        }

        @Override
        public int getItemPosition(@NonNull Object object) {
            // refresh all fragments when data set changed
            return POSITION_NONE;
        }


        @Override
        public int getCount() {
            // Show 5 total pages.
            //1 link rss/1tab
            //list rss size -> so tab
            return ContrucVal.LIST_KEY[inDex].length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return ContrucVal.LIST_KEY[inDex][position];
        }
    }
}
