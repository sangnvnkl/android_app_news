package com.example.sangnv.appnews;

public final class TempCache {


    public static final String[] TINMOI_LINK = {
            "http://vnexpress.net/rss/tin-moi-nhat.rss",
            "http://www.24h.com.vn/upload/rss/tintuctrongngay.rss",
    };

    public static final String[] THETHAO_LINK = {
            "http://vnexpress.net/rss/the-thao.rss",
            "http://www.24h.com.vn/upload/rss/bongda.rss",
    };

    public static final String[] CONGNGHE_LINK = {
            "http://vnexpress.net/rss/so-hoa.rss",
            "http://www.24h.com.vn/upload/rss/otoxemay.rss",
    };

    public static final String[] GIAITRI_LINK = {
            "http://vnexpress.net/rss/giai-tri.rss",
            "http://www.24h.com.vn/upload/rss/phim.rss",
            "http://www.24h.com.vn/upload/rss/giaitri.rss",
    };

    public static final String[] THEGIOI_LINK = {
            "http://vnexpress.net/rss/the-gioi.rss",
    };

    public static final String[] SUCKHOE_LINK = {
            "http://vnexpress.net/rss/suc-khoe.rss",
    };

    public static final String[] PHAPLUAT_LINK = {
            "http://vnexpress.net/rss/phap-luat.rss",
    };

    public static final String[] DULICH_LINK = {
            "http://vnexpress.net/rss/du-lich.rss",
    };

    public static final String[] GIAODUC_LINK = {
            "http://vnexpress.net/rss/giao-duc.rss",
    };

    public static final String[] LIST_CATE = {
            "Tin tới",
            "Thể thao",
            "Công nghệ",
            "Giải trí",
            "Thế giới",
            "Sức khỏe",
            "Pháp luật",
            "Du lịch",
            "Giáo dục",
    };
}
