package com.example.sangnv.appnews;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;


/**
 * Created by Truong on 5/7/2018.
 */

public class WebViewActivity extends AppCompatActivity {
    String url;
    WebView myWebView;
    ProgressBar myProgress;
    ProgressBar myProgress2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        Bundle bundle = getIntent().getExtras();
        url = bundle.getString("url");

        myProgress = (ProgressBar) findViewById(R.id.progressBar);
        myProgress.setMax(100);
        myProgress.setProgress(0);

        myProgress2 = (ProgressBar) findViewById(R.id.progressBar2);

        myWebView = (WebView) findViewById(R.id.webView);
        //myWebView.setWebChromeClient(new WebChromeClient());

        myWebView.setWebViewClient(new MyWebViewClient());

        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.getSettings().setLoadWithOverviewMode(true);
        myWebView.getSettings().setUseWideViewPort(true);
        myWebView.getSettings().setBuiltInZoomControls(true);

        myWebView.loadUrl(url);

//        myProgressDialog = ProgressDialog.show(this, "", "Loading...");
//        if (myProgressDialog.isShowing()) {
//            myProgressDialog.dismiss();
//        }
    }


    @Override
    public void onBackPressed() {
        if (myWebView.canGoBack()) {
            myWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }


    class MyWebViewClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);

            WebViewActivity.this.setTitle(view.getTitle());
            myProgress.setVisibility(View.VISIBLE);
            myProgress.setProgress(10);

            myProgress2.bringToFront();
            myProgress2.setVisibility(View.VISIBLE);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
//                    toast.cancel();
                    myProgress2.setVisibility(View.GONE);
                }
            }, 1000);
        }
        @Override
        public void onPageCommitVisible(WebView view, String url) {
            super.onPageCommitVisible(view, url);
//            myProgress.setProgress(60);
        }
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            myProgress2.setVisibility(View.GONE);
            myProgress.setProgress(100);
//            toast = Toast.makeText(WebViewActivity.this, "✓", Toast.LENGTH_LONG);
//            toast.show();

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
//                    toast.cancel();
                    myProgress.setVisibility(View.GONE);
                }
            }, 1000);
        }


    }
}