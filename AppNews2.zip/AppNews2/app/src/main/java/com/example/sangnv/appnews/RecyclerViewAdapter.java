package com.example.sangnv.appnews;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sangnv.appnews.RssGet.Item_RSS;
import com.example.sangnv.appnews.RssItemFragment.OnListFragmentInteractionListener;
import com.squareup.picasso.Picasso;

import java.util.List;


/**
 * {@link RecyclerView.Adapter} that can display a {@link } and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private final List<Item_RSS> mValues;
    private final OnListFragmentInteractionListener mListener;

    public RecyclerViewAdapter(List<Item_RSS> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_rssitem, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);
        if (holder.mItem.isNull()) {
            holder.mTitle.setText(null);
            holder.mDate.setText(null);
            holder.imageView.setImageResource(R.drawable.ic_error);
        } else {
            try {
                holder.mTitle.setText(mValues.get(position).getTitle());
                holder.mDate.setText(mValues.get(position).getDate());
                if (!holder.mItem.getDescription().isEmpty())
                    Picasso.get().load(holder.mItem.getDescription()).into(holder.imageView);
            } catch (Exception e){
                Log.e("Bind adapter" , "Error");
            }
        }

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    mListener.onListFragmentInteraction(holder.mItem);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView mTitle;
        public final ImageView imageView;
        public final TextView mDate;
        public Item_RSS mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mTitle = (TextView) view.findViewById(R.id.txt_rss_title);
            mDate = (TextView) view.findViewById(R.id.txt_rss_date);
            imageView = view.findViewById(R.id.imageView);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mTitle.getText() + "'";
        }
    }
}
